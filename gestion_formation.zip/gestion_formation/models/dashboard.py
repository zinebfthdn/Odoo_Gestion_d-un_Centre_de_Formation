from odoo import models, fields, api

class GestionDashboard(models.Model):
    _name = 'gestion.dashboard'
    _description = 'Dashboard de gestion'

    total_participants = fields.Integer(string="Participants", compute="_compute_counts")
    total_formateurs = fields.Integer(string="Formateurs", compute="_compute_counts")
    total_formations = fields.Integer(string="Formations", compute="_compute_counts")

    @api.depends()
    def _compute_counts(self):
        for record in self:
            record.total_participants = self.env['gestion.participant'].search_count([])
            record.total_formateurs = self.env['gestion.formateur'].search_count([])
            record.total_formations = self.env['gestion.formation'].search_count([])

    @api.model
    def default_get(self, fields_list):
        # Empêche la création multiple — une seule instance
        existing = self.search([], limit=1)
        if existing:
            return existing.read()[0]
        return super(GestionDashboard, self).default_get(fields_list)
