from odoo import models, fields, api, _
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)

class Participant(models.Model):
    _name = 'gestion.participant'
    _description = 'Participant à une formation'

    name = fields.Char(string='Nom du participant', required=True)
    email = fields.Char(string='Email', required=True)
    phone = fields.Char(string='Téléphone')
    formation_id = fields.Many2one('gestion.formation', string='Formation', required=True)
    date_inscription = fields.Date(string="Date d'inscription", default=fields.Date.today)

    partner_id = fields.Many2one('res.partner', string="Client")
    facture_id = fields.Many2one('account.move', string="Facture liée")

    state = fields.Selection([
        ('draft', 'Brouillon'),
        ('confirmed', 'Confirmé'),
        ('done', 'Terminé'),
        ('cancelled', 'Annulé'),
    ], string='Statut', default='draft', readonly=True, copy=False, tracking=True)

    montant_paye = fields.Float(string='Montant payé (€)', digits=(6, 2), default=0.0)
    reste_a_payer = fields.Float(string='Reste à payer (€)', compute='_compute_reste_a_payer', store=True)

    etat_paiement = fields.Selection([
        ('paye', 'Payé'),
        ('non_paye', 'Non payé'),
        ('partiel', 'Partiellement payé'),
    ], string="État paiement", compute='_compute_etat_paiement', store=True)

    reste_a_payer_text = fields.Char(string="Statut paiement détaillé", compute='_compute_reste_paiement_text', store=False)

    sale_order_id = fields.Many2one('sale.order', string="Commande de vente")

    @api.depends('reste_a_payer')
    def _compute_reste_paiement_text(self):
        for rec in self:
            if rec.reste_a_payer > 0:
                rec.reste_a_payer_text = "Reste à payer : %.2f €" % rec.reste_a_payer
            else:
                rec.reste_a_payer_text = "Payé intégralement"

    @api.depends('montant_paye', 'formation_id.prix')
    def _compute_reste_a_payer(self):
        for rec in self:
            prix = rec.formation_id.prix or 0.0
            rec.reste_a_payer = max(prix - rec.montant_paye, 0)

    @api.depends('montant_paye', 'formation_id.prix')
    def _compute_etat_paiement(self):
        for rec in self:
            prix = rec.formation_id.prix or 0.0
            if rec.montant_paye >= prix and prix > 0:
                rec.etat_paiement = 'paye'
            elif rec.montant_paye == 0:
                rec.etat_paiement = 'non_paye'
            else:
                rec.etat_paiement = 'partiel'

    def action_confirm(self):
        for rec in self:
            if rec.state != 'draft':
                raise UserError(_("Vous ne pouvez confirmer qu'un participant en état 'Brouillon'."))
            rec.state = 'confirmed'

    def action_done(self):
        for rec in self:
            if rec.state != 'confirmed':
                raise UserError(_("Vous ne pouvez terminer qu'un participant en état 'Confirmé'."))
            rec.state = 'done'

    def action_cancel(self):
        for rec in self:
            if rec.state == 'done':
                raise UserError(_("Vous ne pouvez pas annuler un participant déjà terminé."))
            rec.state = 'cancelled'

    def imprimer_attestation(self):
        for rec in self:
            if rec.state != 'done':
                raise UserError(_("Vous ne pouvez imprimer l'attestation que pour un participant terminé."))
        return self.env.ref('gestion_formation.action_report_attestation').report_action(self)

    def action_imprimer_facture(self):
        for rec in self:
            if rec.montant_paye < rec.formation_id.prix:
                raise UserError(_("Le participant n'a pas réglé la totalité du montant."))
        return self.env.ref('gestion_formation.action_report_facture').report_action(self)

    def action_creer_commande_vente(self):
        SaleOrder = self.env['sale.order']
        for rec in self:
            if not rec.partner_id:
                raise UserError(_("Le participant n'a pas de client lié."))
            if not rec.formation_id.product_id:
                raise UserError(_("La formation n'est pas liée à un produit."))

            commande = SaleOrder.create({
                'partner_id': rec.partner_id.id,
                'order_line': [(0, 0, {
                    'product_id': rec.formation_id.product_id.id,
                    'product_uom_qty': 1,
                    'price_unit': rec.formation_id.prix or 0.0,
                })]
            })
            rec.sale_order_id = commande.id

            return {
                'type': 'ir.actions.act_window',
                'name': 'Commande de Vente',
                'res_model': 'sale.order',
                'res_id': commande.id,
                'view_mode': 'form',
                'target': 'current',
            }



    def action_generer_et_afficher_facture(self):
        self.action_generer_facture()
        self.ensure_one()
        if not self.facture_id:
            raise UserError("Erreur : la facture n'a pas pu être générée.")
        return {
            'type': 'ir.actions.act_window',
            'name': 'Facture',
            'res_model': 'account.move',
            'res_id': self.facture_id.id,
            'view_mode': 'form',
            'target': 'current',
        }

    def action_generer_facture(self):
        for participant in self:
            if not participant.partner_id:
                raise UserError("Aucun client lié au participant.")
            if not participant.formation_id or not participant.formation_id.product_id:
                raise UserError("La formation doit être liée à un produit.")

            product = participant.formation_id.product_id

            account = product.property_account_income_id or \
                    product.categ_id.property_account_income_categ_id

            if not account:
                raise UserError("Aucun compte de revenu défini pour ce produit ou catégorie.")

            facture = self.env['account.move'].create({
                'move_type': 'out_invoice',
                'partner_id': participant.partner_id.id,
                'invoice_line_ids': [(0, 0, {
                    'name': product.name,
                    'quantity': 1,
                    'price_unit': participant.formation_id.prix,
                    'product_id': product.id,
                    'account_id': account.id,
                })]
            })

            participant.facture_id = facture.id
