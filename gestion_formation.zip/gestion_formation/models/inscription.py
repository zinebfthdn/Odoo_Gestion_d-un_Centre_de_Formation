from odoo import models, fields, api

class GestionInscription(models.Model):
    _name = "gestion.inscription"
    _description = "Inscription à une formation"

    participant_id = fields.Many2one('res.partner', string="Participant")
    formation_id = fields.Many2one('gestion.formation', string="Formation")

    def envoyer_email_confirmation(self):
        template = self.env.ref('gestion_formation.email_template_confirmation_inscription')
        for record in self:
            template.send_mail(record.id, force_send=True)

    @api.model
    def create(self, vals):
        record = super().create(vals)
        record.env.cr.commit()
        record.env.ref('gestion_formation.email_template_confirmation_inscription').send_mail(record.id, force_send=True)
        return record
