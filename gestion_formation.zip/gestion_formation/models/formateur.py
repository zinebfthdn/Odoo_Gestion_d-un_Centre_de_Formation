from odoo import models, fields

class Formateur(models.Model):
    _name = 'gestion.formateur'
    _description = 'Formateur'

    name = fields.Char(string='Nom complet', required=True)
    email = fields.Char(string='Email')
    telephone = fields.Char(string='Téléphone')
    specialite = fields.Char(string='Spécialité')
    bio = fields.Text(string='Biographie')

    formation_ids = fields.One2many('gestion.formation', 'formateur_id', string='Formations données')
