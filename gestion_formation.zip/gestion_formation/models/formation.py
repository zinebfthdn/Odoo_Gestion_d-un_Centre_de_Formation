from odoo import models, fields, api
from odoo.exceptions import UserError
from datetime import datetime

class Formation(models.Model):
    _name = 'gestion.formation'
    _description = 'Modèle Formation'
    _order = 'date_debut desc'

    name = fields.Char(string='Nom de la formation', required=True)
    date_debut = fields.Date(string='Date de début')
    date_fin = fields.Date(string='Date de fin')
    duree = fields.Integer(string='Durée (jours)', compute='_compute_duree', store=True)

    formateur_id = fields.Many2one('gestion.formateur', string='Formateur')
    prix = fields.Float(string='Prix (€)', digits=(6, 2))
    product_id = fields.Many2one('product.product', string="Produit lié", ondelete='set null')

    lieu = fields.Char(string='Lieu')

    participant_ids = fields.One2many('gestion.participant', 'formation_id', string='Participants')
    participant_count = fields.Integer(string='Nombre de participants', compute='_compute_participant_count', store=True)
    participants_noms = fields.Char(string='Participants inscrits', compute='_compute_participants_noms')

    statut = fields.Selection([
        ('planifiee', 'Planifiée'),
        ('en_cours', 'En cours'),
        ('terminee', 'Terminée'),
        ('annulee', 'Annulée'),
    ], string='Statut', default='planifiee', tracking=True)

    @api.model
    def create(self, vals):
        if not vals.get('product_id'):
            product = self.env['product.product'].create({
                'name': vals.get('name'),
                'type': 'service',
                'list_price': vals.get('prix', 0.0),  
            })
            vals['product_id'] = product.id
        return super().create(vals)

    @api.depends('date_debut', 'date_fin')
    def _compute_duree(self):
        for rec in self:
            if rec.date_debut and rec.date_fin:
                rec.duree = (rec.date_fin - rec.date_debut).days + 1
                if rec.duree < 0:
                    rec.duree = 0
            else:
                rec.duree = 0

    @api.depends('participant_ids')
    def _compute_participant_count(self):
        for rec in self:
            rec.participant_count = len(rec.participant_ids)

    @api.depends('participant_ids.name')
    def _compute_participants_noms(self):
        for rec in self:
            noms = [p.name for p in rec.participant_ids]
            rec.participants_noms = ', '.join(noms) if noms else "Aucun participant"
