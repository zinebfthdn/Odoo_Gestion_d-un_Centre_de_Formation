# -*- coding: utf-8 -*-
{
    'name': "Gestion d'un centre de formation",

    'summary': "Module de gestion complet pour centres de formation : participants, formateurs, formations, et dashboard analytique",

    'description': """
    Ce module permet de gérer efficacement un centre de formation avec :
    - La gestion des participants et formateurs
    - Le suivi des formations proposées
    - Un tableau de bord interactif avec des indicateurs clés
    - La visualisation des données via des graphiques pour une meilleure prise de décision

    Idéal pour les établissements souhaitant digitaliser et centraliser leur gestion.
    """,
    'author': "El Malky Douaa, Feth-Eddine Zineb",
    'website': "https://www.formations.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Education',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'web','sale', 'purchase', 'stock', 'account', 'contacts', 'sale_management', 'mail'],
    'assets': {
        'web.assets_backend': [
            # 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.1/chart.min.js',
            # 'https://cdn.jsdelivr.net/npm/chart.js',
            'https://cdn.jsdelivr.net/npm/chart.js',

        ],
    },

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/dashboard_view.xml',
        'views/formation_views.xml',
        'views/participant_views.xml',
        #'views/email_templates.xml',
        'views/gestion_formateur_views.xml',
        'views/menu.xml',
        'reports/report.xml',
        #'reports/report_attestation.xml',
        'reports/template_attestation.xml',
        'reports/report_facture.xml',
        'reports/facture_template.xml',
    ],

    'installable': True,
    'application': True,
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    
}

